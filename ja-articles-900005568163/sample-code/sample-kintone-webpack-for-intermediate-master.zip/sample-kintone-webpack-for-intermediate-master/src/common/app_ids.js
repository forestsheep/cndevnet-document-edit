const appIds = {
  app1: 95,
  app2: 96,
  app3: 97
};

export default appIds;
