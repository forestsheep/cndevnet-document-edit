const events = ['app.record.create.show', 'app.record.edit.show'];
kintone.events.on(events, event => {
  // ここに処理内容を書く
});
